# KRD Camera Pro — GitHub Actions Build

Project Android siap di-upload ke GitHub. Setiap push ke `main`/`master`, pull request, atau manual `workflow_dispatch` akan menjalankan GitHub Actions dan menghasilkan APK debug sebagai artifact.

## Cara pakai

1. Buat repository baru di GitHub, misalnya `KRD-Camera-Pro`.
2. Upload seluruh isi folder project ini ke repository.
3. Pastikan folder `.github/workflows/android-apk.yml` ikut ter-upload.
4. Buka tab **Actions** di repository.
5. Jalankan **Build KRD Camera Pro APK**.
6. Setelah selesai, buka workflow run tersebut dan download artifact **KRD-Camera-Pro-debug**.

## Catatan
- Workflow menggunakan JDK 17, sesuai kebutuhan AGP 8.x.
- Workflow menggunakan Gradle 8.11.1.
- APK yang dihasilkan adalah debug APK dan cocok untuk pengujian/sideload.
- Untuk rilis Play Store, buat signing key dan workflow release terpisah; jangan menyimpan keystore/password di repository.
